package org.persuasive.smelter.wrappers;

import org.persuasive.smelter.wrappers.ids.SmeltingObject;


public class OreGroup {
	private int amount = -1;
	private SmeltingObject object = null;

	public OreGroup(SmeltingObject obj, int am) {
		amount =  am;
		object = obj;
	}
	public SmeltingObject getObject(){
		return object;
	}
	public int getAmount(){
		return amount;
	}
}
