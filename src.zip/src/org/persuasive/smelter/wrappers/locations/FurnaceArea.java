package org.persuasive.smelter.wrappers.locations;

import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.methods.node.SceneEntities;
import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Locatable;
import org.powerbot.game.api.wrappers.Tile;
import org.powerbot.game.api.wrappers.node.SceneObject;

public enum FurnaceArea {
	EDGEVILLE(new Area(new Tile(3106, 3501, 0), new Tile(3110, 3497, 0))), AL_KHARID(
			new Area(new Tile(3274, 3188, 0), new Tile(3277, 3186, 0))), FALADOR(
			new Area(new Tile(2973, 3371, 0), new Tile(2975, 3368, 0))), PORT_PHASMATYS(
			new Area(new Tile(3683, 3480, 0), new Tile(3687, 3477, 0))), NEITIZNOT(
			new Area(new Tile(2343, 3811, 0), new Tile(2344, 3810, 0)));
	private Area area = null;

	FurnaceArea(Area r) {
		area = r;
	}
	public Area getArea(){
		return area;
	}
	public Tile getCenter(){
		return area.getCentralTile();
	}
	public boolean walkTo(){
		return Walking.walk(getCenter());
	}
	public Tile[] getAllTiles(){
		return area.getTileArray();
	}
	public Tile getNearest(Locatable l){
		return area.getNearest(l);
	}
	public boolean atOven(){
		return area.contains(Players.getLocal());
	}
	public SceneObject getNearestFurnace(){
		final int[] ids = { 26814, 21303, 11666 };
		return SceneEntities.getNearest(ids);
	}
}
