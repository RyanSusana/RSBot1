package org.persuasive.smelter.wrappers.locations;

import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Locatable;
import org.powerbot.game.api.wrappers.Tile;

public enum BankArea {

	EDGEVILLE(new Area(new Tile(3094, 3499, 0), new Tile(3098, 3496, 0))), AL_KHARID(
			new Area(new Tile(3269, 3171, 0), new Tile(3272, 3165, 0))), FALADOR(
			new Area(new Tile(2944, 3371, 0), new Tile(2947, 3368, 0))), PORT_PHASMATYS(
			new Area(new Tile(3687, 3468, 0), new Tile(3691, 3466, 0))), NEITIZNOT(
			new Area(new Tile(2335, 3808, 0), new Tile(2338, 3806, 0)));

	private Area area = null;

	BankArea(Area r) {
		area = r;
	}
	public Area getArea(){
		return area;
	}
	public Tile getCenter(){
		return area.getCentralTile();
	}
	public boolean walkTo(){
		return Walking.walk(getCenter());
	}
	public Tile[] getAllTiles(){
		return area.getTileArray();
	}
	public Tile getNearest(Locatable l){
		return area.getNearest(l);
	}
	public boolean atBank(){
		return area.contains(Players.getLocal());
	}
	
}
