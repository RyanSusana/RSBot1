package org.persuasive.smelter.wrappers.locations;

public enum SmeltArea {
	FALADOR(BankArea.FALADOR, FurnaceArea.FALADOR);
	private BankArea bankA = null;
	private FurnaceArea furnA = null;

	SmeltArea(BankArea bank, FurnaceArea furn) {
		bankA = bank;
		furnA = furn;
	}
	public BankArea getBank(){
		return bankA;
	}
	public FurnaceArea getFurnace(){
		return furnA;
	}
	public boolean atBank(){
		return bankA.atBank();
	}
	public boolean atFurnace(){
		return furnA.atOven();
	}
	public void goToFurnace(){
		furnA.walkTo();
	}
	public void goToBank(){
		bankA.walkTo();
	}
}
