package org.persuasive.smelter.wrappers.ids;

import org.powerbot.game.api.methods.tab.Inventory;
import org.powerbot.game.api.wrappers.node.Item;

public enum SmeltingObject {
	COPPER(436), TIN(438), IRON(440), SILVER(442), COAL(453), GOLD(444), MITHRIL(
			447), ADAMANTITE(449), RUNITE(451), BLURITE(668), EMERALD(1605), SAPPHIRE(
			1607), CRAFTING_SILVER(438), CRAFTING_GOLD(446);
	private int id = -1;

	SmeltingObject(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public Item getInventoryItem() {
		if (!inventoryContains()) {
			return null;
		}
		return Inventory.getItem(id);
	}

	public boolean inventoryContains() {
		return Inventory.contains(id);
	}

	public int getIndex() {
		if(!inventoryContains()){
			return -1;
		}
		return Inventory.indexOf(id);
	}

	public int getInventoryAmount() {
		return Inventory.getCount(id);
	}

}
