package org.persuasive.smelter.wrappers.ids;

import org.persuasive.smelter.wrappers.OreGroup;
import org.powerbot.game.api.methods.Widgets;
import org.powerbot.game.api.wrappers.widget.WidgetChild;


public enum Bar {
	//TODO
	BRONZE(2349, -1, new OreGroup[] { new OreGroup(SmeltingObject.COPPER, 14),
			new OreGroup(SmeltingObject.TIN, 14) }), IRON(2351, 16,
			new OreGroup(SmeltingObject.IRON, 28)), STEEL(2353, 18,
			new OreGroup[] {}), SILVER(2355, 17, new OreGroup(
			SmeltingObject.SILVER, 28)), GOLD(2357, 19, new OreGroup(
			SmeltingObject.GOLD, 28)), MITHRIL(2359, 20, new OreGroup[] {}), ADAMANTITE(
			2361, 21, new OreGroup[] {}), RUNITE(2363, 22, new OreGroup[] {}), BLURITE(
			9467, 15, new OreGroup(SmeltingObject.BLURITE, 28))
	;

	private static final int BAR_WIDGET = 905;
	private int childId = -1;
	private int barId = -1;
	private OreGroup[] groups = null;

	Bar(int id, int child, OreGroup... ore) {
		barId = id;
		childId = child;
		groups = ore;
	}

	public int getBarId() {
		return barId;
	}

	public int getChildId() {
		return childId;
	}

	public OreGroup[] getGroups() {
		return groups;
	}

	public WidgetChild getChild() {
		return Widgets.get(BAR_WIDGET).getChild(barId);
	}
}
