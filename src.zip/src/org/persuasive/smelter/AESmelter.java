package org.persuasive.smelter;

import javax.swing.JDialog;

import org.persuasive.api.gui.EndUI;
import org.persuasive.api.script.MiscMethods;
import org.persuasive.api.script.objects.Logger;
import org.persuasive.api.script.objects.WebPack;
import org.persuasive.smelter.gui.MainUI;
import org.persuasive.smelter.wrappers.OreGroup;
import org.persuasive.smelter.wrappers.ids.Bar;
import org.persuasive.smelter.wrappers.locations.SmeltArea;
import org.powerbot.core.event.events.MessageEvent;
import org.powerbot.core.event.listeners.MessageListener;
import org.powerbot.core.script.ActiveScript;
import org.powerbot.game.api.Manifest;
import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.Widgets;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.methods.widget.Bank;
import org.powerbot.game.api.methods.widget.Camera;
import org.powerbot.game.api.util.Random;
import org.powerbot.game.api.wrappers.node.SceneObject;
import org.powerbot.game.api.wrappers.widget.WidgetChild;

//Before you judge this script please read the todo below there for things i know is wrong
@Manifest(name = "AESmelter[BETA]", description = "Change game chat channel to 'on' else the script will not work. -Persuasive", authors = { "Persuasive" })
public class AESmelter extends ActiveScript implements MessageListener {
	/*
	 * TODO list Better deposit/withdraw |get ids/ore needed for ids.Bar
	 * |Antiban |Paint
	 */

	public static boolean start = false;
	public static SmeltArea area = null;
	public static Bar bar = null;
	public final static Logger LOGGER = new Logger("AEChef");
	private MainUI gui = null;
	private boolean banking = false;
	public static WebPack web;
	public static EndUI end;
	private boolean busySmelting = false;

	private final static String INV_FULL = "no more";// TODO
	private final static int[] DO_NOT_BANK = {};

	@Override
	public void onStart() {
		LOGGER.log("Initializing");
		try {
			gui = new MainUI();
			gui.setVisible(true);
			LOGGER.log("GUI loaded");
		} catch (Exception e) {
			LOGGER.log(e.getMessage());
			stop();
		}
		// edit database
	}

	@Override
	public int loop() {
		if (!start) {
			// things to do while starting up.
			return 50;
		}
		if (Players.getLocal().getAnimation() != -1 || busySmelting) {
			if (Walking.getEnergy() > 69) {
				if (!Walking.isRunEnabled()) {
					Walking.setRun(true);
				}
			}
			return Random.nextInt(1000, 1500);
		}
		if (banking) {
			if (area.atBank()) {
				if (Bank.isOpen()) {
					if (MiscMethods.depositAllExcept(DO_NOT_BANK)) {
						for (OreGroup i : bar.getGroups()) {
							if (Bank.withdraw(i.getObject().getId(),
									i.getAmount())) {
								sleep(Random.nextInt(300, 500));
							} else {
								LOGGER.log("It seems like you do not have enough materials to continue.");
								stop();
							}

						}
						banking = false;
					}
				} else {
					Bank.open();
				}
			} else {
				area.goToBank();
			}
		} else {
			if (Widgets.get(905).validate()) {
				final WidgetChild child = Widgets.get(905).getChild(
						bar.getChildId());
				if (child != null && child.validate()) {
					if (child.interact("Make all")) {
						busySmelting = true;
					}

				}
			} else {
				if (area.atFurnace()) {
					SceneObject furnace = area.getFurnace().getNearestFurnace();
					if (furnace != null) {
						if (furnace.isOnScreen()) {
							furnace.click(true);
						} else {
							Camera.turnTo(furnace);
							sleep(50);
							if (!furnace.isOnScreen()) {
								Walking.walk(furnace.getLocation().randomize(1,
										1));
							}
							return 50;
						}
					} else {
						LOGGER.log("Furnace was detected as null");
					}
				}
			}
		}
		return 50;
	}

	@Override
	public void onStop() {
		web = new WebPack("No current faqs", "www.powerbot.org/community",
				false);
		try {
			end = new EndUI(LOGGER, web);
			end.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			end.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void messageReceived(MessageEvent e) {
		String mes = e.getMessage().toLowerCase();
		if (e.getSender() == null) {
			if (mes.contains("bank full")) {
				LOGGER.log("Your bank is full, please empty it");
				stop();
			}
			if (mes.contains(INV_FULL.toLowerCase())) {
				banking = true;
				busySmelting = false;
			}
		}
		if (e.getSender().equals(Players.getLocal().getName())) {
			if (mes.contains("gui") && mes.contains("load")) {
				try {
					gui = new MainUI();
					gui.setVisible(true);
					LOGGER.log("GUI loaded");
				} catch (Exception x) {
					LOGGER.log("Failed to load gui");
					// LOGGER.log(x.getMessage());
					// stop();
				}
			} else if (mes.contains("stop")
					&& (mes.contains("scr") || mes.contains("ae"))) {
				LOGGER.log("You have remotely stopped the script");
				stop();
			}
		}
	}
}
