package org.persuasive.miner.gui.panels;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextPane;

import org.persuasive.miner.AEMiner;
import org.powerbot.game.api.util.Time;

public class DisplayUI extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public DisplayUI() {

		JLabel lblWhatIGot = new JLabel("What I got:");

		JScrollPane scrollPane = new JScrollPane();
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(
				Alignment.LEADING).addGroup(
				groupLayout
						.createSequentialGroup()
						.addContainerGap()
						.addGroup(
								groupLayout
										.createParallelGroup(Alignment.LEADING)
										.addComponent(scrollPane,
												GroupLayout.DEFAULT_SIZE, 306,
												Short.MAX_VALUE)
										.addComponent(lblWhatIGot))
						.addContainerGap()));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(
				Alignment.LEADING).addGroup(
				groupLayout
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(lblWhatIGot)
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE,
								139, Short.MAX_VALUE).addContainerGap()));

		JTextPane txtpnG = new JTextPane();
		txtpnG.setText(AEMiner.group.getGained() + "\nXP Gained: "
				+ AEMiner.getXpGained() + "\nCash Gained: "
				+ AEMiner.getCashGained() + "gp \n Runtime: "
				+ Time.format(AEMiner.getRuntime()));

		scrollPane.setViewportView(txtpnG);
		setLayout(groupLayout);

	}
}
