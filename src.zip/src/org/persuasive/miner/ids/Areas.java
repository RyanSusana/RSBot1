package org.persuasive.miner.ids;

import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Tile;

public class Areas {
	public static final Area D_RESOURCE_MINE = new Area(new Tile(1045,
			4550, 0), new Tile(1080, 4590, 0));
	public static final Area D_RESOURCE_BANK = new Area(new Tile(1041,
			4574, 0), new Tile(1044, 4578, 0));
	public static final Area L_EAST_MINE = new Area(
			new Tile(3236, 3153, 0), new Tile(3221, 3144, 0));

	public static final Area L_EAST_BANK = new Area(
			new Tile(3270, 3172, 0), new Tile(3269, 3161, 0));

	public static final Area L_WEST_MINE = new Area(
			new Tile(3149, 3142, 0), new Tile(3141, 3152, 0));

	public static final Area L_WEST_BANK = new Area(new Tile[] {
			new Tile(3264, 3174, 0), new Tile(3273, 3174, 0),
			new Tile(3274, 3159, 0), new Tile(3263, 3160, 0) });

	public static final Area AL_MINE = new Area(new Tile(3309, 3286, 0),
			new Tile(3282, 3318, 0));

	public static final Area VARROCK_EAST_MINE = new Area(new Tile(3296,
			3356, 0), new Tile(3275, 3372, 0));

	public static final Area VARROCK_EAST_BANK = new Area(new Tile(3258,
			3414, 0), new Tile(3248, 3427, 0));

	public static final Area VARROCK_WEST_MINE = new Area(new Tile(3186,
			3360, 0), new Tile(3170, 3383, 0));

	public static final Area VARROCK_WEST_BANK = new Area(new Tile[] {
			new Tile(3172, 3451, 0), new Tile(3172, 3428, 0),
			new Tile(3197, 3428, 0), new Tile(3195, 3447, 0) });

	public static final Area BARBARIAN_MINE = new Area(new Tile(3070, 3412,
			0), new Tile(3088, 3432, 0));
	public static final Area BARBARIAN_BANK = new Area(new Tile[] {
			new Tile(3090, 3500, 0), new Tile(3099, 3500, 0),
			new Tile(3101, 3486, 0), new Tile(3089, 3487, 0) });

	public static final Area KHAZARD_MINE = new Area(
			new Tile(2640, 3131, 0), new Tile(2621, 3158, 0));

	public static final Area KHAZARD_BANK = new Area(
			new Tile(2668, 3155, 0), new Tile(2658, 3167, 0));

	public static final Area RIMMINGTON_MINE = new Area(new Tile(2992,
			3225, 0), new Tile(2961, 3253, 0));
	public static final Area RIMMINGTON_BANK = new Area(new Tile[] {
			new Tile(3039, 3239, 0), new Tile(3040, 3230, 0),
			new Tile(3055, 3230, 0), new Tile(3053, 3239, 0) });

	public static final Area FALADOR_BANK = new Area(
			new Tile(3007, 3360, 0), new Tile(3022, 3351, 0));

	public static final Area TAVERLY_MINE = new Area(
			new Tile(2932, 3331, 0), new Tile(2925, 3343, 0));

	public static final Area TAVERLY_BANK = new Area(
			new Tile(2873, 3419, 0), new Tile(2878, 3412, 0));

	public static final Area HOBGLOBIN_MINE = new Area(new Tile(3018, 3813,
			0), new Tile(3035, 3785, 0));

	public static final Area HOBGLOBIN_BANK = new Area(new Tile(3090, 3497,
			0), new Tile(3098, 3487, 0));

	public static final Area BARBARIAN_CLAY = new Area(new Tile(3075, 3405,
			0), new Tile(3088, 3392, 0));

	public static final Area SHILO_MINE = new Area(new Tile(2830, 3008, 0),
			new Tile(2815, 2990, 0));

	public static final Area SHILO_BANK = new Area(new Tile(2842, 2957, 0),
			new Tile(2862, 2952, 0));

	public static final Area S_ARDOUGNE_MINE = new Area(new Tile(2830,
			3008, 0), new Tile(2815, 2990, 0));

	public static final Area S_ARDOUGNE_BANK = new Area(new Tile(2608,
			3221, 0), new Tile(2601, 3237, 0));

}
