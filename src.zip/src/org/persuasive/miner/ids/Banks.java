package org.persuasive.miner.ids;

import org.persuasive.api.script.wrappers.AEBank;

public class Banks {
	public static final AEBank LUM_EAST = new AEBank(Areas.L_EAST_BANK, false),
			LUM_WEST = new AEBank(Areas.L_WEST_BANK, false),
			VARROCK_EAST = new AEBank(Areas.VARROCK_EAST_BANK, false),
			VARROCK_WEST = new AEBank(Areas.VARROCK_WEST_BANK, false),
			RIMMINGTON = new AEBank(Areas.RIMMINGTON_BANK, true),
			BARBARIAN = new AEBank(Areas.BARBARIAN_BANK, false),
			DWARVEN_RESOURCE = new AEBank(Areas.D_RESOURCE_BANK, true);
}
