package org.persuasive.miner.ids;

import org.persuasive.miner.wrappers.area.MineArea;

public class MineAreas {
	public static MineArea LUM_EAST = new MineArea(Areas.L_EAST_MINE),
			LUM_WEST = new MineArea(Areas.L_WEST_MINE),
			VAR_EAST = new MineArea(Areas.VARROCK_EAST_MINE),
			VAR_WEST = new MineArea(Areas.VARROCK_WEST_MINE),
			AL_KHARID = new MineArea(Areas.AL_MINE),

			BARBARIAN = new MineArea(Areas.BARBARIAN_MINE),
			BARBARIAN_CLAY = new MineArea(Areas.BARBARIAN_CLAY),
			RIMMINGTON = new MineArea(Areas.RIMMINGTON_MINE),
			DWARVEN_RESOURCE = new MineArea(Areas.D_RESOURCE_MINE);

}
