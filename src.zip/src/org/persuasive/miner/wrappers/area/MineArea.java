package org.persuasive.miner.wrappers.area;

import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Locatable;

public class MineArea {
	private Area b = null;

	public MineArea(Area n) {
		b = n;
	}

	public void setArea(Area n) {
		b = n;
	}

	public boolean atMine() {
		return b.contains(Players.getLocal());
	}

	public boolean atMine(Locatable i) {
		return b.contains(i);
	}

	public Area getArea() {
		return b;
	}
}
