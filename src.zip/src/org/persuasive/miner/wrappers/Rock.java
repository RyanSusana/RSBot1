package org.persuasive.miner.wrappers;

import org.persuasive.miner.ids.Rocks;
import org.powerbot.game.api.methods.node.SceneEntities;
import org.powerbot.game.api.util.Filter;
import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.node.SceneObject;

public enum Rock {
	CLAY(Rocks.CLAY_ID, 434),TIN(Rocks.TIN_ID, 438), COPPER(Rocks.COPPER_ID, 436), IRON(Rocks.IRON_ID,
			430), SILVER(Rocks.SILVER_ID, 440), COAL(Rocks.COAL_ID, 442), GOLD(
			Rocks.GOLD_ID, 453), MITHRIL(Rocks.MITHRIL_ID, 444), ADAMANTITE(
			Rocks.ADAMANTITE_ID, 447), RUNITE(Rocks.RUNITE_ID, 451), LIMESTONE(
			Rocks.LIME_ID, 3211);
	private int InventoryID;
	private int[] RockIDs;
	private int gained = 0;

	Rock(int[] ID, int inv) {
		InventoryID = inv;
		RockIDs = ID;
	}

	public void addToGained() {
		gained++;
	}
	public int rocksGained(){
		return gained;
	}
	public void addToGained(int i) {
		gained = gained + i;
	}

	public SceneObject getNearest() {
		return SceneEntities.getNearest(RockIDs);
	}

	public SceneObject getSecondNearest(final Area n) {
		return SceneEntities.getNearest(new Filter<SceneObject>() {

			@Override
			public boolean accept(SceneObject e) {
				if (n.contains(e)) {
					for (int i : RockIDs) {
						if ((i == e.getId())
								&& e.getId() != getNearest(n).getId()) {
							return true;
						}
					}
				}
				return false;
			}
		});
	}

	public SceneObject getNearest(final Area n) {
		return SceneEntities.getNearest(new Filter<SceneObject>() {

			@Override
			public boolean accept(SceneObject e) {
				if (n.contains(e)) {
					for (int i : RockIDs) {
						if (i == e.getId()) {
							return true;
						}
					}
				}
				return false;
			}
		});
	}

	public SceneObject[] getAll(final Area n) {
		return SceneEntities.getLoaded(new Filter<SceneObject>() {
			@Override
			public boolean accept(SceneObject e) {
				if (n.contains(e)) {
					for (int i : RockIDs) {
						if (i == e.getId()) {
							return true;
						}
					}
				}
				return false;
			}
		});
	}

	public SceneObject[] getAll() {
		return SceneEntities.getLoaded(RockIDs);
	}

	public int getID() {
		return getNearest().getId();
	}

	public int getInveID() {
		return InventoryID;
	}

	public static boolean waitFor(final boolean c, final long timeout) {
		boolean isValid = false;
		final long past = System.currentTimeMillis();
		final long total = (past + timeout);
		while (System.currentTimeMillis() < total) {
			if (c) {
				isValid = true;
				break;
			}
		}
		return isValid;
	}
}
