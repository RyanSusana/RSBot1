package org.persuasive.miner;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import javax.swing.JDialog;

import org.persuasive.api.gui.DisplayPanel;
import org.persuasive.api.gui.EndUI;
import org.persuasive.api.script.MiscMethods;
import org.persuasive.api.script.objects.Logger;
import org.persuasive.api.script.objects.WebPack;
import org.persuasive.miner.gui.MainUI;
import org.persuasive.miner.gui.panels.DisplayUI;
import org.persuasive.miner.wrappers.Rock;
import org.persuasive.miner.wrappers.RockGroup;
import org.persuasive.miner.wrappers.area.Mine;
import org.persuasive.miner.wrappers.area.PowerMine;
import org.powerbot.core.event.events.MessageEvent;
import org.powerbot.core.event.listeners.MessageListener;
import org.powerbot.core.event.listeners.PaintListener;
import org.powerbot.core.script.ActiveScript;
import org.powerbot.core.script.job.Task;
import org.powerbot.game.api.Manifest;
import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.methods.node.SceneEntities;
import org.powerbot.game.api.methods.tab.Inventory;
import org.powerbot.game.api.methods.tab.Skills;
import org.powerbot.game.api.util.Random;
import org.powerbot.game.api.util.Timer;
import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Entity;
import org.powerbot.game.api.wrappers.Tile;
import org.powerbot.game.api.wrappers.node.SceneObject;

@Manifest(authors = { "Persuasive" }, description = "AEMiner, the best there is", name = "AEMiner[ZETA]")
public class AEMiner extends ActiveScript implements MessageListener,
		PaintListener, MouseListener {
	public static RockGroup group = new RockGroup();
	public static boolean powermine = false;
	public static Mine mine = null;
	public static PowerMine pmine = null;
	private static final int[] PICKAXE = { 1265, 1267, 1269, 1271, 1273, 1275,
			14099, 14107, 15259, 1831, 1829, 1827, 1825, 1823, 946, 12140,
			12142, 12144, 12146, 14277, 14279, 14281, 14283, 14285, 12788 };
	public static boolean start = false;
	public static MainUI gui = null;
	public static final Logger LOGGER = new Logger("AEMiner");
	private static boolean mining = false;
	private static boolean banking = false;
	private static int startExp = 0;
	private static long startTime = 0;

	EndUI end;
	DisplayUI displ;
	WebPack web;

	@Override
	public void onStop() {
		LOGGER.log("Script stopped...Thank you again for choosing me!");
		displ = new DisplayUI();
		DisplayPanel display = new DisplayPanel(displ, "Script Stats");
		try {
			end = new EndUI(LOGGER, web, display);
			end.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			end.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onStart() {
		LOGGER.log("Initializing...");
		web = new WebPack("No current Frequently Asked Questions",
				"www.google.com", false);

		startExp = Skills.getExperience(Skills.MINING);
		startTime = System.currentTimeMillis();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui = new MainUI();
					gui.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		LOGGER.log("GUI loaded!");
	}

	@Override
	public int loop() {
		if (!start) {
			return 100;
		}
		if (Inventory.isFull()
				|| (powermine && (Inventory.getCount() >= pmine.getToDropAt()))) {
			banking = true;
		}
		if ((group.size() == 0)) {
			return 50;
		}
		if (Players.getLocal().getAnimation() != -1 || mining) {
			return 400;
		}
		if (banking) {
			mining = false;
			if (powermine) {
				MiscMethods.dropAllExcept(PICKAXE);
				banking = false;
				return Random.nextInt(50, 200);
			} else {
				if (mine.atBank()) {
					if (mine.getBank().isOpen()) {
						if (MiscMethods.depositAllExcept(PICKAXE)) {
							banking = false;
							return Random.nextInt(50, 200);
						} else {
							LOGGER.log("Error depositing ores");
							return Random.nextInt(50, 200);
						}
					} else {
						if (mine.getBank().open()) {
							return Random.nextInt(50, 200);
						} else {
							LOGGER.log("Error opening the bank/depositbox");
							return Random.nextInt(50, 200);
						}
					}
				} else {
					if(mine.goToBank());
					return Random.nextInt(50, 200);
					
				}
			}
		} else {
			if (powermine ? pmine.atMine() : mine.atMine()) {
				final SceneObject rock = group.getNearest(powermine ? pmine
						.getArea() : mine.getMineArea());
				if (rock != null) {
					mine(powermine ? pmine.getArea() : mine.getMineArea());
					return 50;
				} else {
					if (Walking.getEnergy() > 69) {
						if (!Walking.isRunEnabled()) {
							Walking.setRun(true);
						}
					}
					return 75;
				}
			} else {
				mine.goToMine();
				return Random.nextInt(50, 200);
			}
		}
	}

	public void mine(final Area n) {
		if (n == null) {
			return;
		}
		final Tile loc = group.getNearest(n).getLocation();
		final SceneObject rock = group.getNearest(n);
		if (rock.isOnScreen()) {
			if (rock.interact("Mine")) {
				final Timer t = new Timer(1500);
				while (t.isRunning() && Players.getLocal().getAnimation() == -1) {
					sleep(50);
					if (Players.getLocal().isMoving()) {
						t.reset();
					}
				}
				waitFor(new MiscMethods.AiCondition() {
					@Override
					public boolean activate() {
						if (group.getSecondNearest(n) != null
								&& group.getSecondNearest(n).isOnScreen()) {
							group.getSecondNearest(n).hover();
						}
						if (group.getNearest(n) == null) {
							return false;
						}

						try {
							return SceneEntities.getAt(loc).getId() != group
									.getNearest(n).getId()
									|| Players.getLocal().getAnimation() == -1;
						} catch (Exception e) {
							LOGGER.log("NPE detected: while trying to mine(Succesfully evaded)");
							return false;
						}
					}
				}, Random.nextInt(3000, 5000));
			}
		}
	}

	public static Area getRadiusAroundPlayer(int squareTiles) {
		Tile t = Players.getLocal().getLocation();
		return new Area(new Tile(t.getX() + squareTiles,
				t.getY() + squareTiles, t.getPlane()), new Tile(t.getX()
				- squareTiles, t.getY() - squareTiles, t.getPlane()));

	}

	public static boolean waitFor(final MiscMethods.AiCondition c,
			final long timeout) {
		boolean isValid = false;
		final long past = System.currentTimeMillis();
		final long total = (past + timeout);
		while (System.currentTimeMillis() < total) {
			if (c.activate()) {
				isValid = true;
				break;
			}
			Task.sleep(50);
		}
		return isValid;
	}

	@Override
	public void messageReceived(MessageEvent e) {
		String mes = e.getMessage().toLowerCase();
		if (e.getSender() == Players.getLocal().getName()) {
			if (mes.contains("add")) {
				for (Rock value : Rock.values()) {
					if (mes.contains(value.name().toLowerCase())) {
						group.add(value);
						LOGGER.log("Rock added:  " + value.name());
					}
				}
			} else if (mes.contains("remove")) {
				for (Rock value : Rock.values()) {
					if (mes.contains(value.name().toLowerCase())) {
						group.remove(value);
						LOGGER.log("Rock removed:  " + value.name());
					}
				}
			} else if (mes.equals("clear")) {
				group.clear();
				LOGGER.log("RockList cleared! Add more rocks by typing 'add copper' for example");

			} else if (mes.contains("powermine")) {
				LOGGER.log("This function no longer works...\nTry resetting the script or change the options on the GUI 'AiMiner' and hit start!!");
			} else if (mes.contains("guipopup")) {
				start = false;
				gui.setVisible(true);
			}
		} else if (e.getSender() == null) {
			if (mes.contains("you have managed")) {
				for (Rock i : group.toArray()) {
					if (mes.contains(i.name().replaceAll("_", " ")
							.toLowerCase())) {
						group.get(i).addToGained();
					}
				}
			}
		}
	}

	// ignore this
	public static void guiStart() {
		gui.setVisible(false);
	}

	public void onRepaint(Graphics g2) {
		Graphics2D g = (Graphics2D) g2;
		if (mine.atMine()
				&& (Inventory.isFull() || (powermine && (Inventory.getCount() >= pmine
						.getToDropAt())))) {
			Tile[] tiles = mine.getMineArea().getTileArray();
			g.setColor(Color.black);
			for (Tile t : tiles) {
				if (t != null && t.isOnScreen())
					t.draw(g);
			}
			g.setColor(Color.red);
			for (Rock r : group.toArray()) {
				for (SceneObject obj : r.getAll(powermine ? pmine.getArea()
						: mine.getMineArea())) {
					obj.draw(g);
				}
			}
			g.setColor(Color.yellow);
			SceneObject secobj = group.getSecondNearest(powermine ? pmine
					.getArea() : mine.getMineArea());
			if (secobj != null && secobj.isOnScreen()) {
				secobj.draw(g);
			}
			g.setColor(Color.green);
			g.setColor(Color.yellow);
			SceneObject obj = group.getNearest(powermine ? pmine.getArea()
					: mine.getMineArea());
			if (obj != null && obj.isOnScreen()) {
				obj.draw(g);
			}
		} else {
			if (mine.atBank()) {
				g.setColor(Color.blue);
				Entity nearest = mine.getBank().getNearest();
				if (nearest != null && nearest.isOnScreen()) {
					nearest.draw(g);
				}
			}
		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {

	}

	@Override
	public void mousePressed(MouseEvent arg0) {

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {

	}

	public static int getXpGained() {
		return startExp - Skills.getExperience(Skills.MINING);
	}

	public static long getRuntime() {
		return System.currentTimeMillis() - startTime;
	}

	public static int getCashGained() {
		int start = 0;
		for (Rock i : group.toArray()) {
			try {
				start = start
						+ (MiscMethods.getPrice(i.getInveID()) * i
								.rocksGained());
			} catch (IOException e) {
				LOGGER.log("Failed getting prices");
			}
		}
		return start;
	}

}
