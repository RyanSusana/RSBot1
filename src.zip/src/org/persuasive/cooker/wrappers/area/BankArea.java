package org.persuasive.cooker.wrappers.area;

import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Locatable;
import org.powerbot.game.api.wrappers.Tile;

public enum BankArea {
	AL_KHARID(null);

	private Area area = null;

	BankArea(Area r) {
		area = r;
	}

	public Area getArea() {
		return area;
	}

	public Tile getCenter() {
		return area.getCentralTile();
	}

	public boolean walkTo() {
		return Walking.walk(getCenter());
	}

	public Tile[] getAllTiles() {
		return area.getTileArray();
	}

	public Tile getNearest(Locatable l) {
		return area.getNearest(l);
	}

	public boolean atBank() {
		return area.contains(Players.getLocal());
	}
}
