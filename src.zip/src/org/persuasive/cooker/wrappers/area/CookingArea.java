package org.persuasive.cooker.wrappers.area;


public class CookingArea {
	private int mode = -1;
	private StoveArea cookArea = null;

	private BankArea bankArea = null;

	public CookingArea(BankArea bank, StoveArea stove) {
		mode = 0;
		cookArea = stove;
		bankArea = bank;
	}

	public BankArea getBank() {
		return bankArea;
	}
	public int getMode(){
		return mode;
	}
	public StoveArea getStove() {
		return cookArea;
	}
}
