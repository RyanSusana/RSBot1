package org.persuasive.cooker.wrappers.ingredients;

import org.persuasive.cooker.AEChef;
import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.Widgets;
import org.powerbot.game.api.methods.node.SceneEntities;
import org.powerbot.game.api.methods.tab.Inventory;
import org.powerbot.game.api.wrappers.node.SceneObject;

public enum Recipe {
	HERRING(RawIngredient.RAW_HERRING), SARDINE(RawIngredient.RAW_SARDINE), TUNA(
			RawIngredient.RAW_TUNA), LOBSTER(RawIngredient.RAW_LOBSTER), SWORDFISH(
			RawIngredient.RAW_SWORDFISH), SALMON(RawIngredient.RAW_SALMON), TROUT(
			RawIngredient.RAW_TROUT), PIKE(RawIngredient.RAW_PIKE), SHRIMP(
			RawIngredient.RAW_SHRIMP), ANCHOVY(RawIngredient.RAW_ANCHOVY), ROCKTAIL(
			RawIngredient.RAW_ROCKTAIL), CAVEFISH(RawIngredient.RAW_CAVEFISH);
	private Ingredient[] ingredients;
	private int mode = -1;

	private static int WIDGET_ID = -1;
	private final static int MAKE_ALL = -1;

	Recipe(RawIngredient r) {

		ingredients = new Ingredient[] { r };
		mode = 0;
	}

	public int getMode() {
		return mode;
	}

	public Ingredient[] getIngredients() {
		return ingredients;
	}

	// 1=process of making |2= interacted| 0 = failed to interact with a
	// widget|-1 failed to find a valid stove or another fatal error
	public int make() {
		if (mode == 0) {
			// TODO widgetwork here
			if (Widgets.get(WIDGET_ID).validate()) {
				if (Widgets.get(WIDGET_ID).getChild(MAKE_ALL).validate()) {
					if (Widgets.get(WIDGET_ID).getChild(MAKE_ALL)
							.interact("Make all")) {
						return 2;
					} else {
						return 0;
					}
				}
			}
			SceneObject stove = SceneEntities
					.getNearest(AEChef.AVAILABLE_FIRES);
			if (stove != null) {
				if (stove.isOnScreen()) {
					if (Inventory.isItemSelected()) {
						stove.click(true);
					} else {
						Inventory.selectItem(ingredients[0].getId());
					}
				} else {
					Walking.walk(stove.getLocation().randomize(1, 1));
				}
			} else {
				return -1;
			}
		}
		return 1;
	}

}
