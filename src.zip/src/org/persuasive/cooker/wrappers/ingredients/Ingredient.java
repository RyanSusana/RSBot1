package org.persuasive.cooker.wrappers.ingredients;

public interface Ingredient {
	public abstract int getId();
	public abstract int getAmountNeeded();
}
