package org.persuasive.cooker.wrappers.ingredients;

public enum RawIngredient implements Ingredient {
	RAW_BEEF(), RAW_CHICKEN(), RAW_HERRING(), RAW_SARDINE(), RAW_TUNA(), RAW_LOBSTER(), RAW_SWORDFISH(), RAW_SALMON(), RAW_TROUT(), RAW_PIKE(), RAW_SHRIMP(), RAW_ANCHOVY(), RAW_ROCKTAIL(), RAW_CAVEFISH();
	private int id = -1;

	RawIngredient() {
		id = 0;
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public int getAmountNeeded() {
		return 28;
	}

}
