package org.persuasive.cooker;

import org.persuasive.api.script.objects.Logger;
import org.persuasive.cooker.wrappers.area.BankArea;
import org.persuasive.cooker.wrappers.area.CookingArea;
import org.persuasive.cooker.wrappers.area.StoveArea;
import org.persuasive.cooker.wrappers.ingredients.Ingredient;
import org.persuasive.cooker.wrappers.ingredients.Recipe;
import org.powerbot.core.event.events.MessageEvent;
import org.powerbot.core.event.listeners.MessageListener;
import org.powerbot.core.script.ActiveScript;
import org.powerbot.game.api.Manifest;
import org.powerbot.game.api.methods.tab.Inventory;
import org.powerbot.game.api.methods.widget.Bank;
import org.powerbot.game.api.util.Random;
@Manifest(authors = { "Persuasive" }, description = "Do you want some pepperoniiiii[Italian accent]", name = "AEChef[ALPHA]")
public class AEChef extends ActiveScript implements MessageListener {
	//TODO fill in the ids
	//TODO TEST TEST TEST!!
	//TODO GUI
	public static final Logger LOGGER = new Logger("AEChef");
	public CookingArea area = new CookingArea(BankArea.AL_KHARID,
			StoveArea.AL_KHARID);
	public Recipe recipe = Recipe.TUNA;
	private boolean banking = false;
	private boolean cooking = false;
	private int errorPoints = 0;
	private boolean errorInLoop = false;
	public final static int[] AVAILABLE_FIRES = { -1 };
	public final static int COOKING_ANIMATION = -2;

	public int getMode() {
		if (recipe.getMode() == area.getMode()) {
			return recipe.getMode();
		} else {
			LOGGER.log("Fatal Error in script: recipe.getMode() !=area.getMode()");
			errorPoints = 11;
			return -1;
		}
	}

	public boolean inventoryContains(Ingredient[] s) {
		for (Ingredient t : s) {
			if (!(Inventory.getCount(t.getId()) >= 1)) {
				return false;
			}
		}
		return true;
	}

	public boolean withdraw(Ingredient[] s) {
		for (Ingredient t : s) {
			if (!Bank.withdraw(t.getId(), t.getAmountNeeded())) {
				return false;
			}
		}
		return true;
	}

	// The error methods might seem a little messy
	@Override
	public int loop() {
		if (errorPoints > 10) {
			System.out
					.println("You have gained 10 errors in the last 10 loops, please restart the script or report a bug");
			stop();
		}
		if (errorInLoop) {
			errorInLoop = false;
		} else {
			errorPoints = 0;
			errorInLoop = false;
		}

		if (cooking) {
			// things todo while cooking.
			return Random.nextInt(500, 1000);
		}
		if (inventoryContains(recipe.getIngredients())) {
			banking = false;
		} else {
			banking = true;
			cooking = false;
		}
		if (banking) {
			if (getMode() == 0) {
				if (area.getBank().atBank()) {
					if (Bank.isOpen()) {
						if (Bank.depositInventory()) {
							if (withdraw(recipe.getIngredients())) {
								banking = false;
								return Random.nextInt(50, 200);
							} else {
								LOGGER.log("Error while banking: Withdrawing ingredients");
								errorPoints++;
								errorInLoop = true;
							}
						} else {
							LOGGER.log("Error while banking: Depositing your inventory");
							errorPoints++;
							errorInLoop = true;
						}
					} else {
						if (Bank.open()) {
							return Random.nextInt(50, 200);
						} else {
							LOGGER.log("Error: opening bank");
							errorPoints++;
							errorInLoop = true;
						}

					}
				} else {
					if (area.getBank().walkTo()) {
						return Random.nextInt(50, 200);
					}else{
						LOGGER.log("Error: walkinng to bank");
						errorPoints++;
						errorInLoop = true;
					}
				}
			}
		} else {
			if (getMode() == 0) {
				if (area.getStove().atStove()) {
					if (recipe.make() == 2) {
						cooking = true;
						return Random.nextInt(50, 200);
					} else if (recipe.make() == 0) {
						LOGGER.log("Fatal Error: Failed to interact with the 'Make all' widget");
						errorPoints = 11;
					} else if (recipe.make() == -1) {
						LOGGER.log("Fatal Error: failed to find a stove/something to cook with");
						errorPoints = 11;
					}else{
						return Random.nextInt(50, 200);
					}
				} else {
					if(area.getStove().walkTo()){
						return Random.nextInt(50, 200);
					}else {
						LOGGER.log("Error: opening bank");
						errorPoints++;
						errorInLoop = true;
					}
				}
			}
		}
		//Gives an error a time to reset
		LOGGER.log("Error: Did not do anything in this loop");
		errorPoints++;
		errorInLoop = true;
		return 3000;
	}

	@Override
	public void messageReceived(MessageEvent e) {
	}

}
