package org.persuasive.api.gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import org.persuasive.api.script.objects.Logger;
import org.persuasive.api.script.objects.WebPack;

public class EndUI extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel buttonPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			EndUI dialog = new EndUI(null, null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public EndUI(Logger l, final WebPack w) {
		setResizable(false);
		setTitle("End of: " + l.getName());
		
		setBounds(100, 100, 475, 380);
		{
			buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			{
				JButton btnForum = new JButton("Go To Forum");
				btnForum.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						w.openForum();
					}
				});
				buttonPane.add(btnForum);
			}
			{
				JButton okButton = new JButton("Close");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout
				.setHorizontalGroup(groupLayout
						.createParallelGroup(Alignment.TRAILING)
						.addGroup(
								groupLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												groupLayout
														.createParallelGroup(
																Alignment.LEADING)
														.addComponent(
																buttonPane,
																GroupLayout.PREFERRED_SIZE,
																434,
																GroupLayout.PREFERRED_SIZE)
														.addGroup(
																groupLayout
																		.createSequentialGroup()
																		.addComponent(
																				tabbedPane,
																				GroupLayout.DEFAULT_SIZE,
																				424,
																				Short.MAX_VALUE)
																		.addGap(10)))));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(
				Alignment.LEADING).addGroup(
				Alignment.TRAILING,
				groupLayout
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(tabbedPane, GroupLayout.DEFAULT_SIZE,
								283, Short.MAX_VALUE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(buttonPane, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)));

		JPanel panel = new JPanel();
		tabbedPane.addTab("Log", null, panel, null);

		JScrollPane scrollPane = new JScrollPane();

		JLabel lblNewLabel = new JLabel("Logger:");
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addContainerGap(386, Short.MAX_VALUE))
				.addComponent(scrollPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 433, Short.MAX_VALUE)
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(150, Short.MAX_VALUE))
		);

		JTextArea txtrLogarea = new JTextArea();
		txtrLogarea.setEditable(false);
		txtrLogarea.setText(l.getLog());
		scrollPane.setViewportView(txtrLogarea);
		panel.setLayout(gl_panel);

		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("FAQs", null, panel_1, null);

		JLabel lblFrequentlyAskedQuestions = new JLabel(
				"Frequently asked questions:");

		JScrollPane scrollPane_1 = new JScrollPane();
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(
				Alignment.LEADING).addGroup(
				gl_panel_1
						.createSequentialGroup()
						.addContainerGap()
						.addGroup(
								gl_panel_1
										.createParallelGroup(Alignment.LEADING)
										.addComponent(
												lblFrequentlyAskedQuestions)
										.addComponent(scrollPane_1,
												Alignment.TRAILING,
												GroupLayout.DEFAULT_SIZE, 423,
												Short.MAX_VALUE))
						.addContainerGap()));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(
				Alignment.LEADING).addGroup(
				gl_panel_1
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(lblFrequentlyAskedQuestions)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE,
								224, Short.MAX_VALUE)));

		JTextPane txtpnFawb = new JTextPane();
		txtpnFawb.setText(w.getFAQ());
		scrollPane_1.setViewportView(txtpnFawb);
		panel_1.setLayout(gl_panel_1);
		getContentPane().setLayout(groupLayout);

		txtrLogarea.setEditable(false);
	}

	/**
	 * @wbp.parser.constructor
	 */
	public EndUI(Logger l, final WebPack w, DisplayPanel... displays) {
		setTitle("End of: " + l.getName());
		setBounds(100, 100, 474, 380);
		{
			buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			{
				JButton btnForum = new JButton("Go To Forum");
				btnForum.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						w.openForum();
					}
				});
				buttonPane.add(btnForum);
			}
			{
				JButton okButton = new JButton("Close");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout
				.setHorizontalGroup(groupLayout
						.createParallelGroup(Alignment.TRAILING)
						.addGroup(
								groupLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												groupLayout
														.createParallelGroup(
																Alignment.LEADING)
														.addComponent(
																buttonPane,
																GroupLayout.PREFERRED_SIZE,
																434,
																GroupLayout.PREFERRED_SIZE)
														.addGroup(
																groupLayout
																		.createSequentialGroup()
																		.addComponent(
																				tabbedPane,
																				GroupLayout.DEFAULT_SIZE,
																				424,
																				Short.MAX_VALUE)
																		.addGap(10)))));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(
				Alignment.LEADING).addGroup(
				Alignment.TRAILING,
				groupLayout
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(tabbedPane, GroupLayout.DEFAULT_SIZE,
								283, Short.MAX_VALUE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(buttonPane, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)));

		JPanel panel = new JPanel();
		tabbedPane.addTab("Log", null, panel, null);

		JScrollPane scrollPane = new JScrollPane();

		JLabel lblNewLabel = new JLabel("Logger:");
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addContainerGap(386, Short.MAX_VALUE))
				.addComponent(scrollPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 433, Short.MAX_VALUE)
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 211, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(81, Short.MAX_VALUE))
		);

		JTextArea txtrLogarea = new JTextArea();
		txtrLogarea.setText(l.getLog());
		scrollPane.setViewportView(txtrLogarea);
		panel.setLayout(gl_panel);

		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("FAQs", null, panel_1, null);

		JLabel lblFrequentlyAskedQuestions = new JLabel(
				"Frequently asked questions:");

		JScrollPane scrollPane_1 = new JScrollPane();
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(
				Alignment.LEADING).addGroup(
				gl_panel_1
						.createSequentialGroup()
						.addContainerGap()
						.addGroup(
								gl_panel_1
										.createParallelGroup(Alignment.LEADING)
										.addComponent(
												lblFrequentlyAskedQuestions)
										.addComponent(scrollPane_1,
												Alignment.TRAILING,
												GroupLayout.DEFAULT_SIZE, 423,
												Short.MAX_VALUE))
						.addContainerGap()));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(
				Alignment.LEADING).addGroup(
				gl_panel_1
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(lblFrequentlyAskedQuestions)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE,
								224, Short.MAX_VALUE)));

		JTextPane txtpnFawb = new JTextPane();
		txtpnFawb.setText(w.getFAQ());
		scrollPane_1.setViewportView(txtpnFawb);
		panel_1.setLayout(gl_panel_1);
		getContentPane().setLayout(groupLayout);
		for (int i = 0; i < displays.length; i++) {
			tabbedPane.addTab(displays[i].getName(), null, displays[i].getPanel(), null);
		}
	}
}
