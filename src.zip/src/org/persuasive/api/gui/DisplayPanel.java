package org.persuasive.api.gui;

import javax.swing.JPanel;

public class DisplayPanel {
	private JPanel panel = null;
	private String name = null;

	public DisplayPanel(JPanel p, String n) {
		panel = p;
		name = n;
	}
	public JPanel getPanel(){
		return panel;
	}
	public String getName(){
		return  name;
	}

}
