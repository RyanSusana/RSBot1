package org.persuasive.api.script.objects;

import javax.swing.JOptionPane;

public class WebPack {
	private String faq;
	private String forum;

	public WebPack(String faq, String forum, boolean connection) {
		if (connection) {
			faq = readWeb(faq);
		} else {
			this.faq = faq;
		}
		this.forum = forum;
	}

	private String readWeb(String site) {
		return "readWeb is not defined";
	}

	public void openForum() {
		String osName = System.getProperty("os.name");
		try {
			if (osName.startsWith("Windows"))
				Runtime.getRuntime().exec(
						"rundll32 url.dll,FileProtocolHandler " + forum);
			else {
				String[] browsers = { "firefox", "opera", "konqueror",
						"epiphany", "mozilla", "netscape" };
				String browser = null;
				for (int count = 0; count < browsers.length && browser == null; count++)
					if (Runtime.getRuntime()
							.exec(new String[] { "which", browsers[count] })
							.waitFor() == 0)
						browser = browsers[count];
				Runtime.getRuntime().exec(new String[] { browser, forum });
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error in opening browser"
					+ ":\n" + e.getLocalizedMessage());
		}
	}

	public String getForum() {
		return forum;
	}

	public String getFAQ() {
		return faq;
	}

}
