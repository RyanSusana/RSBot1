package org.persuasive.api.script;

import javax.swing.GroupLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import org.persuasive.api.gui.DisplayPanel;
import org.persuasive.api.gui.EndUI;
import org.persuasive.api.script.objects.Logger;
import org.persuasive.api.script.objects.WebPack;

public class Test {
	private final static Logger LOGGER = new Logger("Name of your logger");
	private final static WebPack WEBPACK = new WebPack("No faq support",
			"google.com", false);
	private static EndUI ui;
	private final static DisplayPanel PANEL_1 = new DisplayPanel(
			new DisplayUI(), "This is a name of panel1");
	private final static DisplayPanel PANEL_2 = new DisplayPanel(
			new DisplayUI(), "This is a name of a panel2");

	public static void main(String[] args) {
		LOGGER.log("Hi im an example of text");
		LOGGER.log("Hi im an example of text\n using a next line");
		LOGGER.log("Hi im an example of text\nusing\nmore\nthan\n2\nlines\nof\ntext");
		try {
			ui = new EndUI(LOGGER, WEBPACK);
			ui.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			ui.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Example of a JPanel
	public static class DisplayUI extends JPanel {

		/**
	 * 
	 */
		private static final long serialVersionUID = 1L;

		/**
		 * Create the panel.
		 */
		public DisplayUI() {

			JLabel lblWhatIGot = new JLabel("What I got:");

			JScrollPane scrollPane = new JScrollPane();
			GroupLayout groupLayout = new GroupLayout(this);
			groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(
					Alignment.LEADING).addGroup(
					groupLayout
							.createSequentialGroup()
							.addContainerGap()
							.addGroup(
									groupLayout
											.createParallelGroup(
													Alignment.LEADING)
											.addComponent(scrollPane,
													GroupLayout.DEFAULT_SIZE,
													306, Short.MAX_VALUE)
											.addComponent(lblWhatIGot))
							.addContainerGap()));
			groupLayout.setVerticalGroup(groupLayout.createParallelGroup(
					Alignment.LEADING).addGroup(
					groupLayout
							.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblWhatIGot)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE,
									139, Short.MAX_VALUE).addContainerGap()));

			JTextPane txtpnG = new JTextPane();
			txtpnG.setText("Info would go here...\nIf you have other stuff to put in your panel do it!, this is the basic stuff");

			scrollPane.setViewportView(txtpnG);
			setLayout(groupLayout);

		}
	}

}
