package org.persuasive.api.script;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;

import org.powerbot.core.script.job.Task;
import org.powerbot.game.api.methods.Tabs;
import org.powerbot.game.api.methods.input.Mouse;
import org.powerbot.game.api.methods.node.Menu;
import org.powerbot.game.api.methods.tab.Inventory;
import org.powerbot.game.api.methods.widget.Bank;
import org.powerbot.game.api.util.Random;
import org.powerbot.game.api.wrappers.node.Item;
import org.powerbot.game.api.wrappers.widget.WidgetChild;

public class MiscMethods {

	public static void dropAllExcept(int... ids) {
		dropAllExcept(Random.nextBoolean(), ids);
	}
	public static int getPrice(int id) throws IOException {
		URL url = new URL("http://open.tip.it/json/ge_single_item?item=" + id);
		URLConnection con = url.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(
				con.getInputStream()));

		String line = "";
		String inputLine;

		while ((inputLine = in.readLine()) != null) {
			line += inputLine;
		}

		in.close();

		if (!line.contains("mark_price"))
			return -1;

		line = line.substring(line.indexOf("mark_price\":\"")
				+ "mark_price\":\"".length());
		line = line.substring(0, line.indexOf("\""));

		return Integer.parseInt(line);
	}

	public static void dropAllExcept(final boolean mousekeys, final int... ids) {
		if (Tabs.getCurrent() != Tabs.INVENTORY)
			Tabs.INVENTORY.open();

		if (!mousekeys) {
			for (Item item : Inventory.getItems()) {
				if (Arrays.binarySearch(ids, item.getId()) < 0) {
					item.getWidgetChild().interact("Drop");
					Task.sleep(20, 40);
				}
			}
		} else {
			for (int x = 0; x < 4; x++) {
				for (int y = x; y < 28; y += 4) {
					WidgetChild inv = Inventory.getWidget(true);

					if (arrayContains(ids, inv.getChild(y).getChildId())
							|| inv.getChild(y) == null
							|| inv.getChild(y).getChildId() == -1)
						continue;

					if (!inv.getChild(y).getBoundingRectangle()
							.contains(Mouse.getLocation()))
						Mouse.move(
								inv.getChild(y).getCentralPoint().x
										+ Random.nextInt(-3, 3), inv
										.getChild(y).getCentralPoint().y
										+ Random.nextInt(-3, 3));
					if (inv.getChild(y).getBoundingRectangle()
							.contains(Mouse.getLocation())) {
						Mouse.click(false);

						final int yy = getY();

						if (yy == -1)
							Mouse.click(true);
						else {
							Mouse.hop(Mouse.getX(), yy);
							Mouse.click(true);
						}
					}
				}
			}
		}
	}

	private static int getY() {
		final String[] actions = Menu.getActions();
		for (int i = 0; i < actions.length; i++)
			if (actions[i].toLowerCase().contains("drop"))
				return (int) (Menu.getLocation().getY() + 21 + 16 * i);
		return -1;
	}

	public static boolean arrayContains(final int[] arr, final int a) {
		for (final int i : arr)
			if (i == a)
				return true;
		return false;
	}

	public static boolean depositAllExcept(final int... itemIDs) {
		for (Integer i : itemIDs) {
			if (i == null) {
				return false;
			}
		}
		if (Bank.isOpen()) {
			if (Inventory.getCount(true) - Inventory.getCount(true, itemIDs) <= 0) {
				return true;
			}
			if (Inventory.getCount() == 0) {
				return true;
			}
			if (Inventory.getCount(true, itemIDs) == 0) {
				return Bank.depositInventory();
			}
			outer: for (final Item item : Inventory.getItems()) {
				if (item != null && item.getId() != -1) {
					for (final int itemID : itemIDs) {
						if (item.getId() == itemID) {
							continue outer;
						}
					}
					for (int j = 0; j < 5
							&& Inventory.getCount(item.getId()) != 0; j++) {
						if (Bank.deposit(item.getId(), 0)) {
							Task.sleep(40, 120);
						}
					}
				}
			}
			return Inventory.getCount(true) - Inventory.getCount(true, itemIDs) <= 0;
		}
		return false;
	}
	public interface AiCondition {
		public abstract boolean activate();
	}

}
