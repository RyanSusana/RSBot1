package org.persuasive.api.script.movement.teleportation;

public interface TeleportMethod {
	public abstract boolean teleport();

	public abstract boolean isUsable();

}
