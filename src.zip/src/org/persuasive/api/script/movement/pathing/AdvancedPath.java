package org.persuasive.api.script.movement.pathing;

import org.persuasive.api.script.movement.teleportation.TeleportMethod;
import org.powerbot.game.api.methods.Calculations;
import org.powerbot.game.api.methods.Game;
import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.methods.widget.Camera;
import org.powerbot.game.api.wrappers.Tile;
import org.powerbot.game.api.wrappers.node.SceneObject;

public class AdvancedPath extends Path {

	public Tile[] path;
	public PathObject[] objects;
	public TeleportMethod[] teleport;

	public AdvancedPath(Tile[] path, TeleportMethod[] teleport,
			PathObject... objects) {
		this.path = path;
		this.objects = objects;
		this.teleport = teleport;
	}

	private static Tile[] reversePath(Tile tiles[]) {
		Tile r[] = new Tile[tiles.length];
		int i;
		for (i = 0; i < tiles.length; i++) {
			r[i] = tiles[(tiles.length - 1) - i];
		}
		return r;
	}

	@Override
	public boolean walkPath() {
		return walkPath(path, teleport, objects);
	}

	@Override
	public boolean walkReversed() {
		return walkPath(reversePath(path), teleport, objects);
	}

	public boolean walkPath(final Tile[] path, TeleportMethod[] teleports,
			final PathObject... objects) {
		boolean a = false;
		final Tile next = getNext(path);
		final Tile start = getStart(path);
		final Tile dest = Walking.getDestination();
		final Tile myTile = Players.getLocal().getLocation();
		final PathObject nextObject = nextPO(path, objects);
		SceneObject object = null;

		if (nextObject != null) {
			object = nextObject.getSceneObject();
		}
		if (next == null && object == null) {
			if (getNext(path) == null && nextPO(path, objects) == null) {
				for (TeleportMethod teleport : teleports) {
					if (teleport.isUsable()) {
						teleport.teleport();
						break;
					}
				}
			}
		} else if (object != null) {
			Camera.turnTo(object);
			if (object.interact(nextObject.getAction())) {

			}
		} else {
			if (myTile == path[path.length - 1]) {
				return true;
			}

			if ((dest == null || Calculations.distance(myTile, dest) < 6 || Calculations
					.distance(next, Walking.getDestination()) > 3)
					&& object == null) {
				if (!Walking.walk(next)) {
					if (Walking.walk(start)) {
						a = true;
					} else {
						walkTile(getClosestTileOnMap(next));
					}
				} else {
					a = true;
				}
			}
		}

		return a;
	}

	public static Tile getClosestTileOnMap(final Tile tile) {
		if (Game.isLoggedIn()) {
			final Tile loc = Players.getLocal().getLocation();
			final Tile walk = new Tile((loc.getX() + tile.getX()) / 2,
					(loc.getY() + tile.getY()) / 2, Game.getPlane());
			return Calculations.distance(loc, walk) < 15 ? walk
					: getClosestTileOnMap(walk);
		}
		return tile;
	}

	public static boolean walkTile(final Tile tile) {
		if ((Walking.getDestination() == null || (Calculations.distance(Players
				.getLocal().getLocation(), Walking.getDestination()) < 6 && Calculations
				.distance(tile, Walking.getDestination()) > 3))) {
			if (tile.isOnScreen()) {
				return tile.click(true);
			} else if (Calculations.distance(Players.getLocal().getLocation(),
					tile) < 15) {
				return Walking.walk(tile);
			} else {
				return walkTile(getClosestTileOnMap(tile));
			}
		}
		return false;
	}

	public static Tile getStart(final Tile[] tiles) {
		return tiles[0];
	}

	public static Tile getNext(final Tile[] tiles) {
		for (int i = tiles.length - 1; i >= 0; --i) {
			if (Calculations.distance(Players.getLocal().getLocation(),
					tiles[i]) < 7 && Game.getPlane() == tiles[i].getPlane()) {

				return tiles[i];
			}
		}
		return null;
	}

	public static PathObject nextPO(Tile[] tiles, PathObject... pathobjects) {
		for (int i = pathobjects.length - 1; i >= 0; i--) {
			if (Calculations.distanceTo(pathobjects[i].getLocation()) < 6) {
				return pathobjects[i];
			}
		}
		return null;
	}

	@Override
	public void changeFirstTile(Tile t) {
		path[0] = t;
	}

}
