package org.persuasive.api.script.movement.pathing;

import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.wrappers.Tile;
import org.powerbot.game.api.wrappers.map.TilePath;

public class BasicPath extends Path {
	private TilePath tilePath = null;

	public BasicPath(TilePath i) {
		tilePath = i;
	}

	public BasicPath(Tile[] i) {
		TilePath l = Walking.newTilePath(i);
		tilePath = l;
	}

	@Override
	public void changeFirstTile(Tile s) {
		Tile[] i = tilePath.toArray();
		i[0] = s;
		tilePath = new TilePath(i);
	}

	public Tile getLastTile() {
		return tilePath.getEnd();
	}

	@Override
	public boolean walkPath() {
		return tilePath.traverse();
	}

	@Override
	public boolean walkReversed() {
		return tilePath.reverse().traverse();
	}
}
