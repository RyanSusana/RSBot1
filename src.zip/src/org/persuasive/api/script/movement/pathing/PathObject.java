package org.persuasive.api.script.movement.pathing;



import org.powerbot.game.api.methods.node.SceneEntities;
import org.powerbot.game.api.util.Filter;
import org.powerbot.game.api.wrappers.Tile;
import org.powerbot.game.api.wrappers.node.SceneObject;

public class PathObject {

	public Tile location;
	public int id;
	public String interact;
	
	public PathObject(String interact, Tile location, int id) {
		this.id = id;
		this.location = location;
		this.interact = interact;
	}
	
	public Tile getLocation() {
		return location;
	}
	
	public SceneObject getSceneObject() {
		return SceneEntities.getNearest(new Filter<SceneObject>() {
			@Override
			public boolean accept(SceneObject e) {
				return e != null && e.getId() == id && e.isOnScreen();
			}
		});
	}
	
	public int getID() {
		return id;
	}
	
	public String getAction() {
		return interact;
	}
}
