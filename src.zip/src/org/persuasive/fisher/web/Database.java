package org.persuasive.fisher.web;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class Database {
	public String getInputLink() {
		return "http://aifisher.hostoi.com/input.php?";
	}

	public String getOutputLink() {
		return "http://aifisher.hostoi.com/output.php?username=";
	}

	public String getOutput(String name) {
		URL oracle = null;
		String s = "";
		try {
			oracle = new URL(getOutputLink() + name);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					oracle.openStream()));
			s = in.readLine();
			in.close();
		} catch (Exception e) {

		}
		if (oracle == null)
			return null;
		return s;
	}

}
