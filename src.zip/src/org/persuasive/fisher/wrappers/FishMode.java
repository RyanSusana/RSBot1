package org.persuasive.fisher.wrappers;

import org.powerbot.game.api.methods.interactive.NPCs;
import org.powerbot.game.api.methods.tab.Inventory;
import org.powerbot.game.api.util.Filter;
import org.powerbot.game.api.wrappers.interactive.NPC;
import org.powerbot.game.api.wrappers.node.Item;

public enum FishMode {
	TUNA_SWORDFISH("harpoon", new Fish[] { Fish.TUNA, Fish.SWORDFISH },
			new FishZone[] { FishZone.KARAMJA }, 324);
	private int[] npcIds = null;
	private String interaction = null;
	private Fish[] fish;
	private FishZone[] zonesAvailable;

	FishMode(String interaction, Fish[] fishies, FishZone[] zonesAvailable,
			int... npcIds) {
		this.zonesAvailable = zonesAvailable;
		this.npcIds = npcIds;
		fish = fishies;
		this.interaction = interaction;
	}

	public FishZone[] getAvailableZones() {
		return zonesAvailable;
	}

	public Fish[] getFish() {
		return fish;
	}

	public String getInteractionMethod() {
		return interaction;
	}

	public int[] getNpcIds() {
		return npcIds;
	}

	public Item[] getAllInventory() {
		return Inventory.getItems(new Filter<Item>() {

			@Override
			public boolean accept(Item i) {
				for (int j = 0; j < fish.length; j++) {
					if (fish[j].getId() == i.getId()) {
						return true;
					}
				}
				return false;
			}
		});
	}

	public NPC getNearest() {
		return NPCs.getNearest(npcIds);
	}

	public NPC[] getAll() {
		return NPCs.getLoaded(npcIds);
	}
}
