package org.persuasive.fisher.wrappers;

import org.persuasive.api.script.MiscMethods;
import org.persuasive.api.script.movement.pathing.BasicPath;
import org.persuasive.api.script.movement.pathing.Path;
import org.persuasive.api.script.wrappers.AEBank;
import org.persuasive.fisher.AEFisher;
import org.persuasive.fisher.ids.Areas;
import org.persuasive.fisher.ids.Paths;
import org.powerbot.game.api.methods.Walking;
import org.powerbot.game.api.methods.interactive.NPCs;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.methods.widget.Bank;
import org.powerbot.game.api.methods.widget.DepositBox;
import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Tile;
import org.powerbot.game.api.wrappers.interactive.NPC;

public enum FishZone {
	KARAMJA(), DRAYNOR(Areas.DRAYNOR_FISH, Paths.DRAYNOR, Areas.DRAYNOR_BANK,
			false);
	private int mode = -1;
	private Area fishArea = null;
	private AEBank bankArea = null;
	private Path toBank = null;

	// TODO get ids for equipment
	// Stiles = mode 0
	FishZone() {
		mode = 0;
		// TODO get ids
		toBank = new BasicPath(new Tile[] { new Tile(2918, 3173, 0),
				new Tile(2907, 3171, 0), new Tile(2896, 3163, 0),
				new Tile(2892, 3151, 0), new Tile(2882, 3147, 0),
				new Tile(2870, 3147, 0), new Tile(2858, 3145, 0),
				new Tile(2851, 3142, 0) });
		fishArea = new Area(new Tile[] { new Tile(2896, 3195, 0),
				new Tile(2898, 3181, 0), new Tile(2903, 3177, 0),
				new Tile(2912, 3177, 0), new Tile(2912, 3197, 0) });
	}

	// Bank = mode 1
	FishZone(Area fish, Path t, Area bank, boolean bool) {
		mode = 1;
		fishArea = fish;
		bankArea = new AEBank(bank, bool);
		toBank = t;
	}

	// Powerfish = mode 2
	FishZone(Area p) {
		mode = 2;
		fishArea = p;
	}

	public void goToBank() {
		if (mode == 1 || mode == 0 || mode == 4) {
			toBank.walkPath();
		} else {
			Walking.walk(fishArea.getCentralTile().randomize(1, 1));
		}
	}

	public void goToFish() {
		if (mode == 1 || mode == 0 || mode == 4) {
			toBank.walkReversed();
		} else {
			Walking.walk(fishArea.getCentralTile().randomize(1, 1));
		}
	}

	public void doBank() {
		if (mode == -1) {
			System.out.println("Mode has not been set correctly");
			return;
		}
		if (mode == 0) {
			NPC stiles = NPCs.getNearest(11267);
			if (stiles != null) {
				if (stiles.isOnScreen()) {
					stiles.interact("Exchange");
				} else {
					Walking.walk(stiles.getLocation().randomize(2, 2));
				}
			}
		} else if (mode == 1) {
			if (bankArea.atBank()) {
				if (!bankArea.isOpen()) {
					bankArea.open();
				} else {
					AEBank.depositAllExcept(null);
				}
			} else {
				AEFisher.LOGGER.log("Error banking");
			}
		} else if (mode == 2) {
			MiscMethods.dropAllExcept(-1);
		}
	}

	public boolean isPowerfish() {
		return mode == 2;
	}

	public boolean atBank() {
		if (mode == 0) {
			NPC stiles = NPCs.getNearest(11267);
			return (stiles != null);

		}
		if (isPowerfish())
			return true;// always at bank
		return bankArea.atBank();
	}

	public boolean atFish() {
		return fishArea.contains(Players.getLocal());
	}
}
