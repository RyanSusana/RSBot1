package org.persuasive.fisher.wrappers;

public enum Fish {
	TUNA(-1, -1),SWORDFISH(-1,-1), LOBSTER(-1, -1), PIKE(-1, -1), SALMON(-1, -1), SHRIMP(-1, -1), TROUT(
			-1, -1), ANCHOVY(-1, -1), HERRING(-1, -1), SARDINE(-1, -1);
	private int itemId, noteId;

	Fish(int itemId, int notedId) {
		this.itemId = itemId;
		this.noteId = notedId;
	}

	public int getId() {
		return itemId;
	}

	public int getNotedId() {
		return noteId;
	}
}
