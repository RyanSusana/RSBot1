package org.persuasive.fisher;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JDialog;

import org.persuasive.api.gui.EndUI;
import org.persuasive.api.script.objects.Logger;
import org.persuasive.api.script.objects.WebPack;
import org.persuasive.fisher.wrappers.FishMode;
import org.persuasive.fisher.wrappers.FishZone;
import org.powerbot.core.event.listeners.PaintListener;
import org.powerbot.core.script.ActiveScript;
import org.powerbot.game.api.Manifest;
import org.powerbot.game.api.methods.interactive.Players;
import org.powerbot.game.api.methods.tab.Inventory;
import org.powerbot.game.api.methods.widget.Camera;
import org.powerbot.game.api.util.Random;
import org.powerbot.game.api.wrappers.interactive.NPC;

@Manifest(authors = { "Persuasive" }, description = "Do what you can't", name = "AEFisher")
public class AEFisher extends ActiveScript implements PaintListener {
	public static Logger LOGGER = new Logger("AEFisher");
	WebPack web ;
	EndUI end;
	public static FishZone zone = FishZone.KARAMJA;
	public static FishMode mode = FishMode.TUNA_SWORDFISH;
	@Override
	public void onStop(){
		web = new WebPack("No current faqs", "www.powerbot.org/community", false);
		try {
			end = new EndUI(LOGGER, web);
			end.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			end.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public int loop() {
		if (Players.getLocal().isInCombat()) {
			// TODO things to do in combat
			return Random.nextInt(50, 200);
		}
		if (Players.getLocal().isMoving()) {
			// things TODO while moving...pots and such..
			return Random.nextInt(50, 200);
		}
		if ((Players.getLocal().getAnimation() ==-1)
				|| (Players.getLocal().getInteracting() instanceof NPC
						&& Players.getLocal().getInteracting().getId() != 11267 && !Inventory
							.isFull())) {
			return Random.nextInt(50, 200);
		}
		if (Inventory.isFull()) {
			if (zone.isPowerfish()) {
				zone.doBank();
				return Random.nextInt(50, 200);
			} else {
				if (zone.atBank()) {
					zone.doBank();
					return Random.nextInt(50, 200);
				} else {
					zone.goToBank();
					return Random.nextInt(50, 200);
				}
			}
		} else {
			if (zone.atFish()) {
				if (mode.getNearest() != null) {
					NPC fish = mode.getNearest();
					if (fish.isOnScreen()) {
						if (fish.interact(mode.getInteractionMethod())) {
							// stuff TODO when you click the fishing spot
						}
					} else {
						Camera.turnTo(fish);
					}
				} else {
					// TODO importannnntttttt... stuff to do while waiting(pots
					// and such)
					return Random.nextInt(50, 200);
				}
			} else {
				zone.goToFish();
			}
		}
		return 50;
	}

	public void onRepaint(Graphics graphics) {
		Graphics2D g = (Graphics2D) graphics;
		g.setRenderingHints(new RenderingHints(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF));
		g.setColor(new Color(51, 102, 255, 160));
		g.fillRect(564, 243, 167, 212);
		g.setStroke(new BasicStroke(1));
		g.setColor(new Color(0, 0, 0));
		g.drawRect(564, 243, 167, 212);
		g.setColor(new Color(0, 0, 0));
		g.setFont(new Font("Arial", 0, 13));
	}
}
