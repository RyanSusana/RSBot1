package org.persuasive.fisher.ids;

import org.persuasive.api.script.movement.pathing.BasicPath;
import org.powerbot.game.api.wrappers.Tile;

public class Paths {
	public static BasicPath DRAYNOR = new BasicPath(new Tile[] {
			new Tile(3087, 3232, 0), new Tile(3089, 3237, 0),
			new Tile(3091, 3242, 0) });
}
