package org.persuasive.fisher.ids;

import org.powerbot.game.api.wrappers.Area;
import org.powerbot.game.api.wrappers.Tile;

public class Areas {
	 public static Area DRAYNOR_FISH = new Area(new Tile[] { new Tile(3081, 3241, 0), new Tile(3099, 3219, 0), new Tile(3076, 3209, 0), 
			new Tile(3063, 3237, 0) });
	 public static Area DRAYNOR_BANK = new Area(new Tile[] { new Tile(3086, 3247, 0), new Tile(3098, 3247, 0), new Tile(3098, 3239, 0), 
				new Tile(3085, 3239, 0) });
}
